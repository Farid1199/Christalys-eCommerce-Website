@extends('mainLayout.layout2')

@section('title', 'Check')



@section('content')






@endsection